"""Batlytics — Scorecard Screen"""
from kivy.uix.screenmanager import Screen
from kivy.metrics import dp
from kivy.properties import StringProperty, NumericProperty, ListProperty, BooleanProperty
import database as db


class ScorecardScreen(Screen):
    match_id = NumericProperty(0)
    match_title = StringProperty("")
    score_text = StringProperty("")
    overs_text = StringProperty("")
    show_batting = BooleanProperty(True)

    batting_stats = ListProperty([])
    bowling_stats = ListProperty([])
    partnerships = ListProperty([])
    over_summary_text = StringProperty("")

    innings_1_score = StringProperty("")
    innings_2_score = StringProperty("")
    viewing_innings = NumericProperty(1)
    previous_screen = StringProperty("home")

    def on_enter(self):
        """Load scorecard data."""
        if not self.match_id:
            return

        match = db.get_match(self.match_id)
        if match:
            self.match_title = f"{match['team_a']} vs {match['team_b']}"

        self._load_innings(1)

    def _load_innings(self, innings_number):
        """Load data for specific innings."""
        self.viewing_innings = innings_number
        innings = db.get_innings(self.match_id, innings_number)
        if not innings:
            return

        self.score_text = f"{innings['total_runs']}/{innings['total_wickets']}"
        balls = innings['total_overs_balls']
        self.overs_text = f"({balls // 6}.{balls % 6})"

        # Batting stats
        bat = db.get_batting_stats(innings['id'])
        self.batting_stats = bat

        # Bowling stats
        bowl = db.get_bowling_stats(innings['id'])
        self.bowling_stats = bowl

        # Partnerships
        parts = db.get_partnerships(innings['id'])
        self.partnerships = parts

        # Over summary
        overs = db.get_over_summary(innings['id'])
        lines = []
        for k in sorted(overs.keys()):
            ov = overs[k]
            lines.append(f"Over {k+1}: {' '.join(ov['balls'])} = {ov['total']}")
        self.over_summary_text = "\n".join(lines)

        self._rebuild_cards()

    def _rebuild_cards(self):
        """Rebuild the scorecard display widgets."""
        # Batting container
        bat_container = self.ids.get("batting_container")
        if bat_container:
            bat_container.clear_widgets()
            from kivy.uix.boxlayout import BoxLayout
            from kivy.uix.label import Label
            from kivy.uix.gridlayout import GridLayout

            # Header
            header = GridLayout(cols=6, size_hint_y=None, height=dp(36), spacing=dp(2), size_hint_x=None, width=dp(350))
            widths = {"Batsman": dp(120), "SR": dp(50)}
            for h in ["Batsman", "R", "B", "4s", "6s", "SR"]:
                w = widths.get(h, dp(35))
                lbl = Label(
                    text="  " + h if h == "Batsman" else h,
                    font_size='11sp', bold=True,
                    color=(0.5, 0.5, 0.5, 1), size_hint_x=None,
                    width=w
                )
                if h == "Batsman":
                    lbl.halign = 'left'
                    lbl.text_size = (w, None)
                header.add_widget(lbl)
            bat_container.add_widget(header)

            for bs in self.batting_stats:
                name = bs["name"]
                if bs.get("is_out"):
                    how = bs.get("how_out", "out")
                    bowler = bs.get("bowler_name", "")
                    fielder = bs.get("fielder_name", "")
                    if how == "caught" and fielder:
                        name += f"\nc {fielder} b {bowler}"
                    elif how == "bowled":
                        name += f"\nb {bowler}"
                    elif how == "lbw":
                        name += f"\nlbw b {bowler}"
                    elif how == "stumped":
                        if fielder:
                            name += f"\nst {fielder} b {bowler}"
                        else:
                            name += f"\nst b {bowler}"
                    elif how == "run out":
                        name += "\nrun out"
                    elif how == "hit wicket":
                        name += f"\nhit wicket b {bowler}"
                    else:
                        name += f"\n{how}"
                else:
                    name += " *"
                row_h = 48 if bs.get("is_out") else 32
                row = GridLayout(cols=6, size_hint_y=None, height=dp(row_h), spacing=dp(2), size_hint_x=None, width=dp(350))
                
                # Add spaces to each line of the name for left padding
                indented_name = "\n".join("  " + line for line in name.split("\n"))
                is_out = bs.get("is_out")
                name_color = (0.2, 0.2, 0.2, 1) if is_out else (0.1, 0.5, 0.8, 1)
                row.add_widget(Label(text=indented_name, font_size='13sp', color=name_color,
                                     size_hint_x=None, width=dp(120), halign='left',
                                     valign='middle', text_size=(dp(120), None)))
                row.add_widget(Label(text=str(bs["runs"]), font_size='14sp', bold=True,
                                     color=(0.1, 0.1, 0.1, 1), size_hint_x=None, width=dp(35)))
                row.add_widget(Label(text=str(bs["balls_faced"]), font_size='13sp',
                                     color=(0.4, 0.4, 0.4, 1), size_hint_x=None, width=dp(35)))
                row.add_widget(Label(text=str(bs["fours"]), font_size='13sp',
                                     color=(0.4, 0.4, 0.4, 1), size_hint_x=None, width=dp(35)))
                row.add_widget(Label(text=str(bs["sixes"]), font_size='13sp',
                                     color=(0.4, 0.4, 0.4, 1), size_hint_x=None, width=dp(35)))
                row.add_widget(Label(text=str(bs["strike_rate"]), font_size='12sp',
                                     color=(0.4, 0.4, 0.4, 1), size_hint_x=None, width=dp(50)))
                bat_container.add_widget(row)

            # Extras row
            extras = db.get_extras_summary(self.batting_stats[0]["innings_id"] if hasattr(self, '_current_innings_id') else
                                           db.get_innings(self.match_id, self.viewing_innings)["id"])
            extras_parts = []
            if extras["wides"]:
                extras_parts.append(f"{extras['wides']}w")
            if extras["noballs"]:
                extras_parts.append(f"{extras['noballs']}nb")
            if extras["byes"]:
                extras_parts.append(f"{extras['byes']}b")
            extras_text = f"Extras: {extras['total']}"
            if extras_parts:
                extras_text += f" ({', '.join(extras_parts)})"

            extras_row = BoxLayout(size_hint_y=None, height=dp(32), padding=[dp(12), 0, dp(12), 0])
            extras_row.add_widget(Label(text=extras_text, font_size='13sp', bold=True,
                                        color=(0.3, 0.3, 0.3, 1), halign='left', text_size=(None, None)))
            bat_container.add_widget(extras_row)

            # Total row
            innings = db.get_innings(self.match_id, self.viewing_innings)
            if innings:
                total_text = f"Total: {innings['total_runs']}/{innings['total_wickets']} ({innings['total_overs_balls'] // 6}.{innings['total_overs_balls'] % 6} ov)"
                total_row = BoxLayout(size_hint_y=None, height=dp(40), padding=[dp(12), 0, dp(12), 0])
                total_row.add_widget(Label(text=total_text, font_size='16sp', bold=True,
                                           color=(0.1, 0.1, 0.1, 1), halign='left', text_size=(None, None)))
                bat_container.add_widget(total_row)

        # Bowling container
        bowl_container = self.ids.get("bowling_container")
        if bowl_container:
            bowl_container.clear_widgets()
            from kivy.uix.gridlayout import GridLayout
            from kivy.uix.label import Label

            header = GridLayout(cols=5, size_hint_y=None, height=dp(36), spacing=dp(2), size_hint_x=None, width=dp(338))
            widths = {"Bowler": dp(130), "Econ": dp(60)}
            for h in ["Bowler", "O", "R", "W", "Econ"]:
                w = widths.get(h, dp(40))
                lbl = Label(
                    text="  " + h if h == "Bowler" else h,
                    font_size='11sp', bold=True,
                    color=(0.5, 0.5, 0.5, 1), size_hint_x=None,
                    width=w
                )
                if h == "Bowler":
                    lbl.halign = 'left'
                    lbl.text_size = (w, None)
                header.add_widget(lbl)
            bowl_container.add_widget(header)

            for bw in self.bowling_stats:
                row = GridLayout(cols=5, size_hint_y=None, height=dp(32), spacing=dp(2), size_hint_x=None, width=dp(338))
                row.add_widget(Label(text="  " + bw["name"], font_size='13sp',
                                     color=(0.1, 0.5, 0.8, 1), size_hint_x=None,
                                     width=dp(130), halign='left', valign='middle',
                                     text_size=(dp(130), None)))
                row.add_widget(Label(text=bw["overs"], font_size='13sp',
                                     color=(0.3, 0.3, 0.3, 1), size_hint_x=None, width=dp(40)))
                row.add_widget(Label(text=str(bw["runs_conceded"]), font_size='13sp',
                                     color=(0.3, 0.3, 0.3, 1), size_hint_x=None, width=dp(40)))
                row.add_widget(Label(text=str(bw["wickets"]), font_size='14sp', bold=True,
                                     color=(0.1, 0.1, 0.1, 1), size_hint_x=None, width=dp(40)))
                row.add_widget(Label(text=str(bw["economy"]), font_size='13sp',
                                     color=(0.4, 0.4, 0.4, 1), size_hint_x=None, width=dp(60)))
                bowl_container.add_widget(row)
                
        # FoW container
        fow_container = self.ids.get("fow_container")
        if fow_container:
            fow_container.clear_widgets()
            from kivy.uix.boxlayout import BoxLayout
            from kivy.uix.label import Label
            
            # Header
            header_row = BoxLayout(size_hint_y=None, height=dp(36), padding=[dp(12), 0, dp(12), 0])
            header_row.add_widget(Label(text="FALL OF WICKETS", font_size='11sp', bold=True,
                                        color=(0.5, 0.5, 0.5, 1), halign='left', text_size=(None, None)))
            fow_container.add_widget(header_row)

            # Get FoW data
            fow = db.get_fall_of_wickets(db.get_innings(self.match_id, self.viewing_innings)["id"])
            if fow:
                # Format: "1-15 (John, 2.3 ov), 2-45 (Jane, 5.1 ov)"
                fow_strings = []
                for idx, w in enumerate(fow):
                    fow_strings.append(f"{idx+1}-{w['current_score']} ({w['out_name']}, {w['over_number']}.{w['ball_number']} ov)")
                fow_text = ", ".join(fow_strings)
            else:
                fow_text = "No wickets fallen yet."
                
            fow_lbl = Label(text=fow_text, font_size='13sp', color=(0.3, 0.3, 0.3, 1),
                            halign='left', valign='top', size_hint_y=None)
            fow_lbl.bind(width=lambda s, w: setattr(s, 'text_size', (w - dp(24), None)))
            fow_lbl.bind(texture_size=lambda s, ts: setattr(s, 'height', ts[1] + dp(20)))
            fow_container.add_widget(fow_lbl)

    def show_batting_tab(self):
        self.show_batting = True

    def show_bowling_tab(self):
        self.show_batting = False

    def view_innings_1(self):
        self._load_innings(1)

    def view_innings_2(self):
        self._load_innings(2)

    def go_back(self):
        self.manager.transition.direction = 'right'
        self.manager.current = self.previous_screen
