"""Batlytics — Home Screen"""
from kivy.uix.screenmanager import Screen
from kivy.properties import StringProperty, NumericProperty
import database as db


class HomeScreen(Screen):
    recent_match_text = StringProperty("No recent matches")
    recent_score = StringProperty("")
    recent_overs = StringProperty("")
    match_count = NumericProperty(0)
    recent_match_id = NumericProperty(0)
    recent_match_status = StringProperty("")

    def on_enter(self):
        """Refresh data when entering screen."""
        self._load_recent()

    def _load_recent(self):
        matches = db.list_matches()
        self.match_count = len(matches)
        if matches:
            m = matches[0]
            self.recent_match_id = m['id']
            self.recent_match_status = m['status']
            self.recent_match_text = f"{m['team_a']} vs {m['team_b']}"
            # Get innings data
            innings = db.get_innings(m['id'])
            if innings:
                inn = innings[-1]
                self.recent_score = f"{inn['total_runs']}/{inn['total_wickets']}"
                balls = inn['total_overs_balls']
                self.recent_overs = f"({balls // 6}.{balls % 6})"
            else:
                self.recent_score = "Setup"
                self.recent_overs = ""
        else:
            self.recent_match_id = 0
            self.recent_match_status = ""
            self.recent_match_text = "No recent matches"
            self.recent_score = ""
            self.recent_overs = ""

    def continue_recent_match(self):
        if not self.recent_match_id:
            return
        
        if self.recent_match_status == 'live':
            # Continue the live match
            ls = self.manager.get_screen('live_scoring')
            ls.match_id = self.recent_match_id
            self.manager.transition.direction = 'left'
            self.manager.current = 'live_scoring'
        else:
            # Match is finished, just show scorecard
            sc = self.manager.get_screen('scorecard')
            sc.match_id = self.recent_match_id
            sc.previous_screen = 'home'
            self.manager.transition.direction = 'left'
            self.manager.current = 'scorecard'

    def start_new_match(self):
        self.manager.transition.direction = 'left'
        self.manager.current = 'match_setup'

    def go_history(self):
        self.manager.transition.direction = 'left'
        self.manager.current = 'match_history'

    def go_settings(self):
        self.manager.transition.direction = 'left'
        self.manager.current = 'settings'
