"""Batlytics — Settings Screen"""
from kivy.uix.screenmanager import Screen
import database as db
import os


class SettingsScreen(Screen):


    def clear_history(self):
        """Clear all match history by resetting the database."""
        db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "batlytics.db")
        if os.path.exists(db_path):
            os.remove(db_path)
            db.init_db()

    def go_home(self):
        self.manager.transition.direction = 'right'
        self.manager.current = 'home'
