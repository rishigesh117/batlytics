"""Batlytics — Toss Screen"""
import random
import math
from kivy.uix.screenmanager import Screen
from kivy.properties import StringProperty, NumericProperty, BooleanProperty
from kivy.animation import Animation
from kivy.clock import Clock
import database as db


class TossScreen(Screen):
    match_id = NumericProperty(0)
    team_a = StringProperty("")
    team_b = StringProperty("")
    toss_winner = StringProperty("")
    toss_choice = StringProperty("")
    show_decision = BooleanProperty(False)

    def on_enter(self):
        """Load match data and reset toss selection."""
        self.toss_winner = ""
        self.toss_choice = ""
        self.show_decision = False
        
        if self.match_id:
            match = db.get_match(self.match_id)
            if match:
                self.team_a = match["team_a"]
                self.team_b = match["team_b"]
                
    def select_winner(self, winner):
        self.toss_winner = winner
        self.show_decision = True
        
    def select_decision(self, decision):
        self.toss_choice = decision
        db.update_match(self.match_id, toss_winner=self.toss_winner, toss_choice=self.toss_choice.lower())
        self.start_match()

    def go_back(self):
        """Navigate back to match setup, preserving data."""
        setup_screen = self.manager.get_screen('match_setup')
        setup_screen._from_toss_back = True
        self.manager.transition.direction = 'right'
        self.manager.current = 'match_setup'

    def start_match(self):
        """Navigate to live scoring with correct batting order."""
        live_screen = self.manager.get_screen('live_scoring')
        live_screen.match_id = self.match_id
        
        if self.toss_choice.lower() == "bat":
            bat_first = self.toss_winner
        else:
            bat_first = self.team_b if self.toss_winner == self.team_a else self.team_a
            
        live_screen.batting_team = bat_first
        bowl_team = self.team_b if bat_first == self.team_a else self.team_a
        live_screen.bowling_team = bowl_team
        
        self.manager.transition.direction = 'left'
        self.manager.current = 'live_scoring'
