"""Batlytics — Splash Screen"""
from kivy.uix.screenmanager import Screen
from kivy.clock import Clock
from kivy.animation import Animation
from kivy.properties import NumericProperty


class SplashScreen(Screen):
    progress = NumericProperty(0)

    def on_enter(self):
        """Start progress animation and auto-navigate."""
        anim = Animation(progress=100, duration=2.5)
        anim.start(self)
        Clock.schedule_once(self.go_home, 3.0)

    def go_home(self, *args):
        self.manager.transition.direction = 'left'
        self.manager.current = 'home'
