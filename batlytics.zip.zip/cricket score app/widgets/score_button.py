"""Batlytics — Score Button Widget"""
from kivy.uix.button import Button
from kivy.animation import Animation
from kivy.properties import NumericProperty


class ScoreButton(Button):
    """Animated scoring button with press effect."""
    original_font_size = NumericProperty(22)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.font_size = f'{self.original_font_size}sp'
        self.bold = True
        self.background_normal = ''

    def on_press(self):
        """Shrink animation on press."""
        anim = Animation(font_size=self.original_font_size - 2, duration=0.05)
        anim.start(self)

    def on_release(self):
        """Grow back animation on release."""
        anim = Animation(font_size=self.original_font_size, duration=0.1)
        anim.start(self)
