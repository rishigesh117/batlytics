"""Batlytics — Player Card Widget"""
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import StringProperty, NumericProperty


class PlayerCard(BoxLayout):
    """Compact stat card for batsman or bowler display."""
    player_name = StringProperty("")
    stat_line = StringProperty("")
    highlight_color = (0.18, 0.49, 0.20, 1)

    def __init__(self, name="", stats="", **kwargs):
        super().__init__(**kwargs)
        self.player_name = name
        self.stat_line = stats
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = 36
        self.padding = [12, 4, 12, 4]
