"""Batlytics — Bottom Navigation Bar Widget"""
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.properties import StringProperty


class NavBar(BoxLayout):
    """Bottom navigation bar with Home, History, Live, Settings tabs."""
    active_tab = StringProperty('home')

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint_y = None
        self.height = 56
        self.padding = [8, 4, 8, 4]
        self.spacing = 4

        tabs = [
            ('Home', 'home', '\U0001f3e0'),
            ('History', 'match_history', '\U0001f4cb'),
            ('Live', 'live_scoring', '\u26be'),
            ('Settings', 'settings', '\u2699'),
        ]

        for label, screen_name, icon in tabs:
            btn = Button(
                text=f"{icon}\n{label}",
                font_size='11sp',
                halign='center',
                background_normal='',
                background_color=(0, 0, 0, 0),
                color=(0.18, 0.49, 0.20, 1) if screen_name == self.active_tab else (0.5, 0.5, 0.5, 1)
            )
            btn.bind(on_release=lambda inst, sn=screen_name: self._navigate(sn))
            self.add_widget(btn)

    def _navigate(self, screen_name):
        """Navigate to the specified screen."""
        app = self.get_root_window()
        if app and hasattr(app, 'children') and app.children:
            sm = app.children[0]
            if hasattr(sm, 'current'):
                sm.current = screen_name
