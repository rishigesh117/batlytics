"""
Tests for the Batlytics Scoring Engine and Database Layer.
"""
import os
import sys
import pytest
import tempfile

# Add project root to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import database as db
from scoring_engine import ScoringEngine


@pytest.fixture
def test_db():
    """Create a temporary database for testing."""
    fd, path = tempfile.mkstemp(suffix='.db')
    os.close(fd)
    db.init_db(path)
    yield path
    os.unlink(path)


@pytest.fixture
def sample_match(test_db):
    """Create a sample match with players."""
    match_id = db.create_match("Team A", "Team B", 5, 3, db_path=test_db)

    # Add 3 players per team
    a1 = db.add_player(match_id, "Team A", "Player A1", 1, db_path=test_db)
    a2 = db.add_player(match_id, "Team A", "Player A2", 2, db_path=test_db)
    a3 = db.add_player(match_id, "Team A", "Player A3", 3, db_path=test_db)

    b1 = db.add_player(match_id, "Team B", "Player B1", 1, db_path=test_db)
    b2 = db.add_player(match_id, "Team B", "Player B2", 2, db_path=test_db)
    b3 = db.add_player(match_id, "Team B", "Player B3", 3, db_path=test_db)

    return {
        "match_id": match_id,
        "db_path": test_db,
        "team_a": [a1, a2, a3],
        "team_b": [b1, b2, b3]
    }


# ─── Database Tests ──────────────────────────────────────────

class TestDatabase:

    def test_create_match(self, test_db):
        mid = db.create_match("Lions", "Tigers", 20, 11, db_path=test_db)
        assert mid is not None
        match = db.get_match(mid, db_path=test_db)
        assert match["team_a"] == "Lions"
        assert match["team_b"] == "Tigers"
        assert match["overs"] == 20
        assert match["status"] == "setup"

    def test_list_matches(self, test_db):
        db.create_match("A", "B", 10, 5, db_path=test_db)
        db.create_match("C", "D", 15, 8, db_path=test_db)
        matches = db.list_matches(db_path=test_db)
        assert len(matches) == 2

    def test_add_and_get_players(self, test_db):
        mid = db.create_match("X", "Y", 5, 3, db_path=test_db)
        db.add_player(mid, "X", "Alice", 1, db_path=test_db)
        db.add_player(mid, "X", "Bob", 2, db_path=test_db)
        db.add_player(mid, "Y", "Charlie", 1, db_path=test_db)

        x_players = db.get_players(mid, "X", db_path=test_db)
        assert len(x_players) == 2
        assert x_players[0]["name"] == "Alice"

        all_players = db.get_players(mid, db_path=test_db)
        assert len(all_players) == 3

    def test_create_innings(self, test_db):
        mid = db.create_match("A", "B", 10, 5, db_path=test_db)
        iid = db.create_innings(mid, "A", "B", 1, db_path=test_db)
        innings = db.get_innings(mid, 1, db_path=test_db)
        assert innings["batting_team"] == "A"
        assert innings["total_runs"] == 0

    def test_record_and_get_balls(self, test_db):
        mid = db.create_match("A", "B", 10, 5, db_path=test_db)
        p1 = db.add_player(mid, "A", "Bat1", 1, db_path=test_db)
        p2 = db.add_player(mid, "B", "Bowl1", 1, db_path=test_db)
        iid = db.create_innings(mid, "A", "B", 1, db_path=test_db)

        bid = db.record_ball(iid, 0, 0, p1, p2, runs=4, db_path=test_db)
        assert bid is not None

        balls = db.get_balls(iid, db_path=test_db)
        assert len(balls) == 1
        assert balls[0]["runs"] == 4

    def test_delete_ball(self, test_db):
        mid = db.create_match("A", "B", 10, 5, db_path=test_db)
        p1 = db.add_player(mid, "A", "Bat1", 1, db_path=test_db)
        p2 = db.add_player(mid, "B", "Bowl1", 1, db_path=test_db)
        iid = db.create_innings(mid, "A", "B", 1, db_path=test_db)

        bid = db.record_ball(iid, 0, 0, p1, p2, runs=2, db_path=test_db)
        db.delete_ball(bid, db_path=test_db)
        balls = db.get_balls(iid, db_path=test_db)
        assert len(balls) == 0

    def test_partnerships(self, test_db):
        mid = db.create_match("A", "B", 10, 5, db_path=test_db)
        p1 = db.add_player(mid, "A", "Bat1", 1, db_path=test_db)
        p2 = db.add_player(mid, "A", "Bat2", 2, db_path=test_db)
        iid = db.create_innings(mid, "A", "B", 1, db_path=test_db)

        pid = db.create_partnership(iid, p1, p2, db_path=test_db)
        db.update_partnership(pid, runs_add=15, balls_add=10, db_path=test_db)

        active = db.get_active_partnership(iid, db_path=test_db)
        assert active["runs"] == 15
        assert active["balls"] == 10

    def test_batting_stats(self, test_db):
        mid = db.create_match("A", "B", 10, 5, db_path=test_db)
        p1 = db.add_player(mid, "A", "Bat1", 1, db_path=test_db)
        p2 = db.add_player(mid, "B", "Bowl1", 1, db_path=test_db)
        iid = db.create_innings(mid, "A", "B", 1, db_path=test_db)

        db.record_ball(iid, 0, 0, p1, p2, runs=4, db_path=test_db)
        db.record_ball(iid, 0, 1, p1, p2, runs=6, db_path=test_db)
        db.record_ball(iid, 0, 2, p1, p2, runs=1, db_path=test_db)

        stats = db.get_batting_stats(iid, db_path=test_db)
        assert len(stats) == 1
        assert stats[0]["runs"] == 11
        assert stats[0]["balls_faced"] == 3
        assert stats[0]["fours"] == 1
        assert stats[0]["sixes"] == 1

    def test_bowling_stats(self, test_db):
        mid = db.create_match("A", "B", 10, 5, db_path=test_db)
        p1 = db.add_player(mid, "A", "Bat1", 1, db_path=test_db)
        p2 = db.add_player(mid, "B", "Bowl1", 1, db_path=test_db)
        iid = db.create_innings(mid, "A", "B", 1, db_path=test_db)

        db.record_ball(iid, 0, 0, p1, p2, runs=2, db_path=test_db)
        db.record_ball(iid, 0, 1, p1, p2, runs=0, is_wicket=1, db_path=test_db)

        stats = db.get_bowling_stats(iid, db_path=test_db)
        assert len(stats) == 1
        assert stats[0]["wickets"] == 1
        assert stats[0]["runs_conceded"] == 2
        assert stats[0]["legal_balls"] == 2


# ─── Scoring Engine Tests ────────────────────────────────────

class TestScoringEngine:

    def _setup_engine(self, sample_match):
        """Helper to set up a scoring engine ready for ball recording."""
        engine = ScoringEngine(sample_match["match_id"], db_path=sample_match["db_path"])
        engine.start_innings("Team A", "Team B", 1)
        engine.set_openers(sample_match["team_a"][0], sample_match["team_a"][1])
        engine.set_bowler(sample_match["team_b"][0])
        return engine

    def test_record_runs(self, sample_match):
        engine = self._setup_engine(sample_match)
        result = engine.record_ball(runs=4)
        assert result["total_runs"] == 4
        assert result["overs"] == "0.1"

    def test_dot_ball(self, sample_match):
        engine = self._setup_engine(sample_match)
        result = engine.record_ball(runs=0)
        assert result["total_runs"] == 0
        assert result["overs"] == "0.1"

    def test_six(self, sample_match):
        engine = self._setup_engine(sample_match)
        result = engine.record_ball(runs=6)
        assert result["total_runs"] == 6

    def test_strike_rotation_odd_runs(self, sample_match):
        engine = self._setup_engine(sample_match)
        original_striker = engine.striker_id
        engine.record_ball(runs=1)
        # Striker should have swapped
        assert engine.striker_id != original_striker

    def test_strike_no_rotation_even_runs(self, sample_match):
        engine = self._setup_engine(sample_match)
        original_striker = engine.striker_id
        engine.record_ball(runs=2)
        # Striker should remain same
        assert engine.striker_id == original_striker

    def test_wide_ball(self, sample_match):
        engine = self._setup_engine(sample_match)
        result = engine.record_ball(is_wide=True)
        assert result["total_runs"] == 1  # 1 wide extra
        assert engine.legal_balls == 0  # does not count as legal

    def test_noball(self, sample_match):
        engine = self._setup_engine(sample_match)
        result = engine.record_ball(runs=1, is_noball=True)
        assert result["total_runs"] == 2  # 1 run + 1 noball extra
        assert engine.legal_balls == 0  # does not count as legal

    def test_wicket(self, sample_match):
        engine = self._setup_engine(sample_match)
        result = engine.record_ball(is_wicket=True, wicket_type="bowled")
        assert result["total_wickets"] == 1
        # Check need_new_batsman event
        event_types = [e["type"] for e in result["events"]]
        assert "wicket" in event_types

    def test_undo(self, sample_match):
        engine = self._setup_engine(sample_match)
        engine.record_ball(runs=4)
        assert engine.total_runs == 4

        result = engine.undo()
        assert result["undone"] is True
        assert result["total_runs"] == 0
        assert engine.legal_balls == 0

    def test_overs_display(self, sample_match):
        engine = self._setup_engine(sample_match)
        assert engine.overs_display == "0.0"
        engine.record_ball(runs=1)
        assert engine.overs_display == "0.1"

    def test_run_rate(self, sample_match):
        engine = self._setup_engine(sample_match)
        engine.record_ball(runs=6)
        engine.record_ball(runs=6)
        engine.record_ball(runs=6)
        engine.record_ball(runs=6)
        engine.record_ball(runs=6)
        engine.record_ball(runs=6)
        # 36 runs in 1 over = 36.0 run rate
        assert engine.run_rate == 36.0

    def test_innings_over_all_out(self, sample_match):
        engine = self._setup_engine(sample_match)
        # max_wickets = 3 - 1 = 2
        engine.record_ball(is_wicket=True)
        engine.new_batsman(sample_match["team_a"][2])
        engine.record_ball(is_wicket=True)
        assert engine.is_innings_over()

    def test_complete_over_events(self, sample_match):
        engine = self._setup_engine(sample_match)
        # Bowl 6 legal deliveries
        for i in range(5):
            engine.record_ball(runs=0)
        result = engine.record_ball(runs=0)
        event_types = [e["type"] for e in result["events"]]
        assert "over_complete" in event_types
        assert "need_new_bowler" in event_types


# ─── Voice Input Tests ───────────────────────────────────────

class TestVoiceInput:

    def test_parse_command(self):
        from voice_input import VoiceInput
        vi = VoiceInput.__new__(VoiceInput)
        vi._available = False

        assert vi._parse_command("four")["action"] == "runs"
        assert vi._parse_command("four")["value"] == 4
        assert vi._parse_command("six")["value"] == 6
        assert vi._parse_command("wicket")["action"] == "wicket"
        assert vi._parse_command("wide")["action"] == "wide"
        assert vi._parse_command("no ball")["action"] == "noball"
        assert vi._parse_command("zero")["value"] == 0
        assert vi._parse_command("single")["value"] == 1
        assert vi._parse_command("unknown stuff") is None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
